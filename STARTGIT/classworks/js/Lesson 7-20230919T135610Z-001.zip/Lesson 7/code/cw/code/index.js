/*
Реализовать функцию для создания объекта "пользователь".
Написать функцию createNewUser(), которая будет создавать и возвращать объект newUser. 

При вызове функция должна спросить у вызывающего имя и фамилию. 

Используя данные, введенные пользователем, создать объект newUser со свойствами firstName и lastName. 

Добавить в объект newUser метод getLogin(), который будет возвращать первую букву имени пользователя, соединенную с фамилией пользователя, все в нижнем регистре (например, Ivan Kravchenko → ikravchenko). 

Создать пользователя с помощью функции createNewUser(). Вызвать у пользователя функцию getLogin(). Вывести в консоль результат выполнения функции.
*/

//ES5

const userInfo = {
    name: "Philip",
    surname: "Sevene",
    birthday : "01.01.1950"
}
/*
function CreateNewUser (name, sname) {
    this.firstName = name;
    this.lastName = sname;
}

CreateNewUser.prototype.getLogin = function () {
   return (this.firstName.charAt(0) + this.lastName).toLowerCase()
}

const newUser = new CreateNewUser(userInfo.name, userInfo.surname);


Дополнить функцию createNewUser() методами подсчета возраста пользователя и его паролем.

Возьмите выполненное задание выше (созданная вами функция createNewUser()) и дополните ее следующим функционалом: При вызове функция должна спросить у вызывающего дату рождения (текст в формате dd.mm.yyyy) и сохранить ее в поле birthday. 

Создать метод getAge() который будет возвращать сколько пользователю лет. 

Создать метод getPassword(), который будет возвращать первую букву имени пользователя в верхнем регистре, соединенную с фамилией (в нижнем регистре) и годом рождения. (например, Ivan Kravchenko 13.03.1992 → Ikravchenko1992). Вывести в консоль результат работы функции createNewUser(), а также функций getAge() и getPassword() созданного объекта.
*/


//ES6

class CreateNewUser {
    constructor(name, sname, birthday) {
        this.firstName = name;
        this.lastName = sname;
        this.birthday = birthday
    }
    getLogin () {
        return (this.firstName.charAt(0) + this.lastName).toLowerCase()
    }
    getAge () {
        return  new Date().getFullYear() -  this.birthday.split(".")[2]
    }
    getPassword() {
        return this.firstName.charAt(0).toUpperCase() + this.lastName.toLowerCase() + this.birthday.split(".")[2]
    }
}

const newUser = new CreateNewUser(userInfo.name, userInfo.surname, userInfo.birthday);

/*
Створіть клас Phone, який містить змінні number, model і weight.
Створіть три екземпляри цього класу.
Виведіть на консоль значення їх змінних.
Додати в клас Phone методи: receiveCall, має один параметр - ім'я. Виводить на консоль повідомлення "Телефонує {name}". Метод getNumber повертає номер телефону. Викликати ці методи кожного з об'єктів.
*/

// 1
class Phone {
    constructor (number, model, weight) {
        this.number = number;
        this.model = model;
        this.weight = weight;
    }

    receiveCall (name) {
        console.log(`Телефонує ${name}`);
    }

    getNumber(){
        return this.number
    }
}

const iphone = new Phone ("23523", "x10", "234")



//2 

/*
Реалізуйте клас Worker (Працівник), який матиме такі властивості: name (ім'я), surname (прізвище),
rate (ставка за день роботи), days (кількість відпрацьованих днів).
Також клас повинен мати метод getSalary(), який виводитиме зарплату працівника.
Зарплата - це добуток (множення) ставки rate на кількість відпрацьованих днів days.
*/



class Worker extends Phone {
    constructor (name, surname, rate, days, number = "28247594", weight = 324, model = "14") {
        super(number, model, weight)
        this.name = name;
        this.surname = surname;
        this.rate = rate;
        this.days = days
    }

    getSalary () {
        console.log(this.rate * this.days);
    }
}

const worker = new Worker("Ivan", "Iavnov", 50, 30)
console.dir(worker)


